//
//  MainPage.swift
//  birdie3
//
//  Created by Charles Lazaroni on 5/4/24.
//

import SwiftUI

struct MainWorkoutsPage: View {
    var body: some View {
        VStack {
            Text("BIRDIE")
                .font(Font.custom("Unbounded-ExtraBold", size: 24))
            .padding(.bottom,-5)
            Text("Complete a Training Assesment to unlock all workouts")
                .multilineTextAlignment(.center)
                .padding(.horizontal,25)
                .font(Font.custom("Poppins-SemiBold", size: 18))
                .lineSpacing(0.5)
            
                .padding(.bottom,5)
            HStack{
                Text("Schedule Your Next Lift")
                    .font(Font.custom("Poppins-SemiBold", size: 14))
                    .foregroundColor(.blue)
                Image(systemName: "arrow.right")
                   .resizable()
                   .aspectRatio(contentMode: .fit)
                   .frame(width: 15, height: 9)
                   .foregroundColor(.blue)
            }
            
            
            CurrentInstructorComponent() // Optional: ignore safe areas if necessary
        }
        .padding()
        
        Spacer()
    }
}

#Preview {
    MainWorkoutsPage()
}
