//
//  CurrentInstructorComponent.swift
//  birdie3
//
//  Created by Charles Lazaroni on 5/4/24.
//

import SwiftUI

import SwiftUI

struct CurrentInstructorComponent: View {
    var body: some View {
        ZStack(alignment: .topLeading) {
            // Your background image
            Image("CBum")
                .resizable()
                .scaledToFill()
                .frame(width: 350, height:450) // Adjust size based on your needs
                .cornerRadius(15)
                .clipped()

            // Content on top of the image
            VStack(alignment: .leading, spacing: 8) {
                // Top information (Profile Image and Name)
                HStack {
                    Image(systemName:"person.crop.circle") // Replace with your profile image asset name
                        .resizable()
                        .frame(width: 40, height: 40)
                        .clipShape(Circle())
                        .foregroundColor(.white)
                    
                    VStack(alignment: .leading) {
                        Text("Chris")
                            .font(Font.custom("Poppins-SemiBold", size: 20))
                            .foregroundColor(.white)
                        Text("Pro Bodybuilder")
                            .font(Font.custom("Poppins-SemiBold", size: 14))
                            .foregroundColor(.white)

                    }
                }

                Spacer()

                // Bottom Information
                VStack(alignment: .leading) {
                    HStack {
                        VStack(alignment: .center, spacing: 1) {
                            Text("30")
                                .font(Font.custom("Poppins-SemiBold", size: 30))
                                .bold()
                                .foregroundColor(.white)
                            
                            Text("Min")
                                .font(Font.custom("Poppins-SemiBold", size: 13))
                                .foregroundColor(.white)
                        }

                        VStack(alignment: .leading) {
                            Text("Training Assesment")
                                .font(Font.custom("Poppins-SemiBold", size: 20))
                                .bold()
                                .foregroundColor(.white)

                            Text("Full Body Strength")
                                .font(Font.custom("Poppins-regular", size: 12))
                                .foregroundColor(.gray)
                        }
                    }
                    .padding(.bottom)

                    HStack {
                        // Display five star rating
                        ForEach(0..<5) { _ in
                            Image(systemName: "star.fill")
                                .foregroundColor(.blue)
                        }
                    }
                    HStack {
                        Text("4.9 Rating | 82 Completions")
                            .font(Font.custom("Poppins-SemiBold", size: 14))
                            .foregroundColor(.white)
                        // Preview Button
                        Button(action: {
                            // Action for preview button
                        }) {
                            Text("PREVIEW")
                                .font(Font.custom("Poppins-SemiBold", size: 14))
                                .font(Font.custom("Poppins-Bold", size: 14))
                                .padding(.vertical, 8)
                                .padding(.horizontal, 20)
                                .background(Color.blue)
                                .cornerRadius(25)
                                .foregroundColor(.black)
                        }
                    }
                }
            }
            .padding()
        }
        .frame(width: 350, height: 450) // Adjust size to match your image
        .background(Color.black)
        .cornerRadius(15)
       // .shadow(radius: 10)
    }
}

#Preview {
    CurrentInstructorComponent()
}
