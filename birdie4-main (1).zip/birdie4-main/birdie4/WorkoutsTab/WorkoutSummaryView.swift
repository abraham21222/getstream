//
//  WorkoutSummaryView.swift
//  birdie3
//
//  Created by Charles Lazaroni on 5/4/24.
//

import SwiftUI

struct WorkoutSummaryView: View {
    var body: some View {
        ZStack {
            Color.black
                .edgesIgnoringSafeArea(.all)

            ScrollView {
                // GeometryReader for tracking scroll position
                GeometryReader { geometry in
                    let offset = geometry.frame(in: .global).minY
                    Image("BodyBuilder")
                        .resizable()
                        .scaledToFill()
                        .frame(width: UIScreen.main.bounds.width, height: 600) // Adjust size as needed
                        .clipped()
                        .offset(y: offset > 0 ? -offset : 0) // Moves image up as you scroll up
                }
                .frame(height: 600) // Height should match the image

                VStack {
                    // Apply a parallax-like movement effect to text
                    GeometryReader { geometry in
                        let offset = geometry.frame(in: .global).minY
                        VStack {
                            Text("WELCOME TO\nTHE PARTY")
                                .font(Font.custom("Unbounded-ExtraBold", size: 30))
                                .multilineTextAlignment(.center)
                                .foregroundColor(.white)
                                .offset(y: offset > 0 ? -offset / 5 : 0) // Adjust this factor to control the animation

                            Text("Dumbbells • Barbell")
                                .font(Font.custom("Poppins-regular", size: 15))
                                .foregroundColor(.gray)
                                .offset(y: offset > 0 ? -offset / 5 : 0)
                            
                            HStack {
                                Spacer()
                                VStack {
                                    Image(systemName: "heart")
                                        .foregroundColor(.white)
                                        .font(Font.custom("Poppins-regular", size: 20))
                                    Text("Save")
                                        .font(Font.custom("Poppins-regular", size: 15))
                                        .foregroundColor(.white)
                                }
                                .padding(.horizontal)

                                VStack {
                                    Image(systemName: "calendar")
                                        .font(Font.custom("Poppins-regular", size: 20))
                                        .foregroundColor(.white)
                                    Text("Schedule")
                                        .font(Font.custom("Poppins-regular", size: 15))
                                        .foregroundColor(.white)
                                }
                                .padding(.horizontal)
                                VStack {
                                    Image(systemName: "paperplane")
                                        .font(Font.custom("Poppins-regular", size: 20))
                                        .foregroundColor(.white)
                                    Text("Share")
                                        .font(Font.custom("Poppins-regular", size: 15))
                                        .foregroundColor(.white)
                                }
                                .padding(.horizontal)
                                Spacer()
                            }
                            .padding(.vertical,5)
                            .offset(y: offset > 0 ? -offset / 5 : 0)
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .frame(height: 200)
                }
               .padding(.top, 50)
            }
            .edgesIgnoringSafeArea(.top)
            
            VStack{
                Spacer()
                Text("BEGIN WORKOUT")
                    .font(Font.custom("Poppins-SemiBold", size: 18))
                    .padding(.vertical, 10)
                    .frame(maxWidth: .infinity)
                    .background(Color.blue)
                    .cornerRadius(25)
                    .foregroundColor(.black)
            }
        }
    }
}



#Preview {
    WorkoutSummaryView()
}
