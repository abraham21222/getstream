//
//  birdie4App.swift
//  birdie4
//
//  Created by Charles Lazaroni on 5/5/24.
//

import SwiftUI

@main
struct birdie4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
